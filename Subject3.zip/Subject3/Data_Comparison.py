import os
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_absolute_error

def read_txt_file(file_path, option):
    """
    Reads a .txt file and extracts numeric values based on the selected option (X, Y, or Z).
    The function extracts values from position 7 to the end and fills the rest with zeros to make an array of length 146.
    
    :param file_path: Path to the .txt file.
    :param option: The option selected by the user ('X', 'Y', or 'Z').
    :return: Array of 146 positions with the extracted numeric values and remaining filled with zeros.
    """
    data = []
    with open(file_path, 'r') as file:
        for line in file:
            parts = line.split(',')
            for part in parts:
                if part.strip().startswith(option):
                    value = float(part.split('=')[1])
                    data.append(value)
    
    # Select the position for calibration
    data_from_7_onwards = data[1:]
    
    # Ensure the array has exactly 146 elements, padding with zeros if necessary
    result = np.zeros(145)
    result[:len(data_from_7_onwards)] = data_from_7_onwards[:145]
    return result

def read_csv_file(file_path):
    """
    Reads a .csv file, processes it to keep 150 values after downsampling.
    
    :param file_path: Path to the .csv file.
    :return: Array of extracted numeric values after downsampling.
    """
    data = []
    with open(file_path, 'r', encoding= 'utf-8') as file:
        lines = file.readlines()[10:445]  # Skip first line and limit to 450 lines
        for i, line in enumerate(lines):
            if i % 3 == 0:  # Downsample by taking every 3rd line
                value = float(line.split(';')[1].replace('"', '').replace(',', '.'))
                #value1 = -1 * value
                data.append(value)
    return np.array(data)

def plot_and_calculate(array1, array2):
    """
    Plots the two arrays and calculates the MAE and max value ratio.
    
    :param array1: First array of values (from the .txt file).
    :param array2: Second array of values (from the .csv file).
    """
    plt.figure(figsize=(12, 7))
    
    # Plot both arrays
    plt.plot(array1, label='Sensors Data', color='blue')
    plt.plot(array2, label='Kinovea Data', color='orange')
    
    # Calculate MAE
    mae = mean_absolute_error(array1, array2)
    
    # Calculate ratio of maximums
    max_ratio = np.sum(np.sort(np.abs(array1))[-4:]) / np.sum(np.sort(np.abs(array2))[-4:])
    
    # Add text with MAE and max ratio
    plt.text(0.02, 0.98, f"MAE: {mae:.4f}\nMax Ratio: {max_ratio:.4f}", 
             ha='left', va='top', transform=plt.gca().transAxes,
             bbox=dict(facecolor='white', edgecolor='black', boxstyle='round,pad=0.5'))
    
    # Customize plot
    plt.legend(loc='upper right')
    plt.title('Comparison of Data Arrays')
    plt.xlabel('Sample Index')
    plt.ylabel('Value')
    plt.grid(True)
    
    # Show plot
    plt.tight_layout()
    plt.show()

def calibrate_arrays(array1, array2):
    """
    Calibrates two arrays so that both start from the same point by adjusting
    the arrays such that their first values become zero.
    
    :param array1: First array of values.
    :param array2: Second array of values.
    :return: Tuple of calibrated arrays (array1_calibrated, array2_calibrated).
    """
    # Find the first value of each array
    start1 = array1[0]
    start2 = array2[0]
    
    # Adjust both arrays to start from zero
    array1_calibrated = array1 - start1
    array2_calibrated = array2 - start2
    
    return array1_calibrated, array2_calibrated

def main():
    # Ask for file names and option
    #txt_file = input("Enter the name of the .txt file (including extension): ")
    #csv_file = input("Enter the name of the .csv file (including extension): ")
    #option = input("Choose the axis to analyze (Abduction/Adduction (Select X), Flexion/Extension(Select Y), Pronation/Supination (Select Z)): ").upper()
    txt_file = "Subject4_Flexion.txt"
    csv_file = "Flexion_K.csv"
    option = "Y"
    # Construct file paths assuming files are in the current directory
    txt_path = os.path.join(os.getcwd(), txt_file)
    csv_path = os.path.join(os.getcwd(), csv_file)
    
    # Read files and extract data
    array1 = read_txt_file(txt_path, option)
    array2 = read_csv_file(csv_path)
    
    #Calibrate both arrays 
    array1_calibrated, array2_calibrated = calibrate_arrays(array1,array2)
    # Plot and calculate statistics
    plot_and_calculate(array1_calibrated, array2_calibrated)

if __name__ == "__main__":
    main()
