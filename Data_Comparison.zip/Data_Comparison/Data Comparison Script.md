Data Comparison Script
This Python script is designed to compare and analyze data from two different file formats: .txt and .csv. It reads data from these files, processes it, and generates comparison plots, allowing users to visually and quantitatively compare data arrays from two sources. Additionally, it supports calibration of the data arrays to ensure that both arrays represent the same starting point, making the comparison more meaningful.

Features
File Handling:
Reads data from .txt and .csv files.
Supports selection of data channels from .txt files based on user input (X, Y, or Z axis).
Downsamples .csv files to 150 points for comparison.

Array Calibration:
Before plotting, the script calibrates both arrays to ensure that they represent the same moment in time. This is done by shifting one array until both arrays align at their starting points. If further alignment is needed, you can manually adjust this process by iteratively shifting the arrays until a close match is achieved.

Plotting and Statistics:
Visualizes the data using matplotlib.
Displays statistical measures such as Mean Absolute Error (MAE) to quantify the difference between the two data arrays.


How to Use
1. File Setup
Place your .txt and .csv files in the same directory as this script.
The .txt file should contain data with lines like X: value, Y: value, or Z: value, where each line represents a different axis.
The .csv file should contain numeric data that will be compared to the .txt data.
2. Running the Script
Open a terminal in the directory containing this script and your data files.

Run the script using Python:
python Data_Comparison.py

The script will prompt you to input:

The name of the .txt file.
The name of the .csv file.
The axis to analyze (X, Y, or Z for the .txt file).

3. Calibration Process
After reading the data, the script automatically calibrates both arrays to start from the same point (i.e., the first value of each array becomes zero).
If the arrays are not perfectly aligned, you can manually adjust the arrays by shifting one array point by point until the graphs represent the same moment in time. This alignment is crucial for ensuring an accurate comparison of both datasets.

4. Output
The script generates a plot comparing the two datasets.
It calculates and displays the Mean Absolute Error (MAE) between the two data arrays.
Customization
You can modify the file paths and axis selection directly in the script to avoid user prompts, by changing the txt_file, csv_file, and option variables in the main function.

Requirements
Python 3.x
Required Python libraries:
numpy
matplotlib
sklearn

To install the necessary libraries, you can run:
pip install numpy matplotlib scikit-learn

Notes
The script pads arrays with zeros if the data length is less than 150 points to ensure consistency during comparison.
Downsampling is applied to the .csv file to reduce it to 150 values for a fair comparison with the .txt data.
License
This project is open-source and available under the MIT License.