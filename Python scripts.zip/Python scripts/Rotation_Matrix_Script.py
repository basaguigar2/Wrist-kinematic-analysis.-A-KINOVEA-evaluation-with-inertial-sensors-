import serial
import numpy as np
import time
from scipy.spatial.transform import Rotation as R
import matplotlib.pyplot as plt

def open_port(com_port):
    try:
        return serial.Serial(port=com_port, baudrate=9600, timeout=1)
    except serial.SerialException:
        print(f"Could not open port: {com_port}")
        return None

def parse_quaternion(line):
    parts = line.strip().split(',')
    sensor_id = int(parts[0][1:]) 
    w, x, y, z = map(float, parts[1:])
    return sensor_id, R.from_quat([x, y, z, w])

arduino1 = open_port('COM6') 
arduino2 = open_port('COM8')  

def main():
    output_data = []
    data = []
    data_arm = []
    frame_count = 0
    try:
        start_time = time.time()
        continuar = True
        while continuar:
            if time.time() - start_time > 15:
                print("Time finished")
                continuar = False
            line1 = arduino1.readline().decode().strip()
            line2 = arduino2.readline().decode().strip()
            if line1.startswith('Q') and line2.startswith('Q'):
                _, rot1 = parse_quaternion(line1)
                _, rot2 = parse_quaternion(line2)
                relative_orientation = rot2 * rot1.inv()
                euler_angles = relative_orientation.as_euler('zyx', degrees=True)
                euler_pron = rot2.as_euler('zyx', degrees=True)
                data.append(euler_angles)
                data_arm.append(euler_pron)
                output_string = f"Frame: {frame_count}, X: {euler_angles[0]:.2f}, Y: {euler_angles[1]:.2f}, Z: {euler_pron[2]:.2f}"
                print(output_string)
                output_data.append(output_string)
                frame_count += 1
    except KeyboardInterrupt:
        print("Program terminated by user")
    finally:
        arduino1.close()
        arduino2.close()
        if data:
            with open("basilio_m_taza.txt", "w") as file:
                for line in output_data:
                    file.write(line + "\n")
            fig, axs = plt.subplots(3, 1, figsize=(10, 8))
            axs[0].plot([d[0] for d in data], label='Abduction/Adduction')
            axs[1].plot([d[1] for d in data], label='Flexion/Extension', color='green')
            axs[2].plot([d[2] for d in data_arm], label='Pronation/Supination', color='red')
            for ax in axs:
                ax.legend()
                ax.set_xlabel('Muestra')
                ax.set_ylabel('Ángulo (grados)')
                ax.set_ylim(-120, 120)
            plt.tight_layout()
            plt.show()

if __name__ == '__main__':
    main()
