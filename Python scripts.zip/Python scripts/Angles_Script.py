import serial
import time
import numpy as np
import matplotlib.pyplot as plt

def open_port(com_port):
    try:
        return serial.Serial(port=com_port, baudrate=115200, timeout=1)
    except serial.SerialException:
        print(f"Cannot open port: {com_port}")
        return None

arduino_hand = open_port("COM8")
arduino_arm = open_port("COM6")

def read_angles(arduino):
    if arduino is not None:
        try:
            line = arduino.readline().decode('utf-8').strip()
            if "Euler:" in line:
                parts = line.split(" ")
                x = float(parts[2])
                y = float(parts[4])
                z = float(parts[6])
                return np.array([x, y, z])
        except serial.SerialException:
            print(f"Error reading port: {arduino.port}")
    return None

def difference_calculation(ang1, ang2):
    return tuple(ang1[i] - ang2[i] for i in range(len(ang1)))

def main():
    data_hand = []
    data_arm = []
    final_data = []
    angles_output = []
    try:
        start_time = time.time()
        frame_count = 0
        while time.time() - start_time < 15:
            angles_hand = read_angles(arduino_hand)
            angles_arm = read_angles(arduino_arm)
            data_hand.append(angles_hand)
            data_arm.append(angles_arm)
            diferencia = difference_calculation(angles_hand, angles_arm)
            final_data.append(diferencia)
            angles_output.append(f"Frame: {frame_count}, X={diferencia[0]:.2f}, Y={diferencia[1]:.2f}, Z={angles_arm[2]:.2f}")
            print(angles_output[-1])
            frame_count += 1
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("Program terminated by user")
    finally:
        if arduino_hand:
            arduino_hand.close()
        if arduino_arm:
            arduino_arm.close()
        if final_data:
            with open("basilio_taza.txt", "w") as file:
                for item in angles_output:
                    file.write(item + "\n")
            fig, axs = plt.subplots(3, 1, figsize=(10, 8))
            axs[0].plot([d[0] for d in final_data], label='Abduction/Adduction')
            axs[1].plot([d[1] for d in final_data], label='Flexion/Extension', color='green')
            axs[2].plot([d[2] for d in data_arm], label='Pronation/Supination', color='red')
            for ax in axs:
                ax.legend()
                ax.set_xlabel('Muestra')
                ax.set_ylabel('Ángulo (grados)')
                ax.set_ylim(-120, 120)
            plt.tight_layout()
            plt.show()

if __name__ == '__main__':
    main()
